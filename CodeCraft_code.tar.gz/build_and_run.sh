#!/bin/bash
cd CodeCraft-2019
python src/CodeCraft-2019.py /home/xi/Documents/code/competition/2019huawei/2019软挑-初赛-SDK/SDK/SDK_python/CodeCraft-2019/1-map-exam-1/car.txt /home/xi/Documents/code/competition/2019huawei/2019软挑-初赛-SDK/SDK/SDK_python/CodeCraft-2019/1-map-exam-1/road.txt /home/xi/Documents/code/competition/2019huawei/2019软挑-初赛-SDK/SDK/SDK_python/CodeCraft-2019/1-map-exam-1/cross.txt /home/xi/Documents/code/competition/2019huawei/2019软挑-初赛-SDK/SDK/SDK_python/CodeCraft-2019/1-map-exam-1/answer.txt


