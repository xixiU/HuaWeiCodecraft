#!/bin/bash
cd CodeCraft-2019
python src/CodeCraft-2019.py ~/Documents/code/competition/2019huawei/1-map-training-2/car.txt ~/Documents/code/competition/2019huawei/1-map-training-2/road.txt ~/Documents/code/competition/2019huawei/1-map-training-2/cross.txt /home/xi/Documents/code/competition/2019huawei/1-map-training-2/answer.txt
