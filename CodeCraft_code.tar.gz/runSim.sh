python simulator.py CodeCraft-2019/1-map-exam-1/car.txt CodeCraft-2019/1-map-exam-1/road.txt CodeCraft-2019/1-map-exam-1/cross.txt CodeCraft-2019/1-map-exam-1/answer.txt


